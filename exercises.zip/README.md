# WorkoutHevy
 Workout tracker like Hevy, but free and more analytical


 Vision (In order of what should be achieved first):
 
 - Read data, add data
 - Show the usual graphs of each muscle or muscle group or exercise
 - Include A LOT of exercises, from which you could always choose alternatives if you lack equipment or don't like the feel of an exercise
 - Have a nice, clean GUI for dekstop (Dekstop first, then MAYBE android)
 - Include a 3D model of a person, muscles colored in according to a configurable heatmap
 - Be able to generate workout plans to hit each or the most important muscles. Be able to generate a unique workout each time, based on equipment

 Achieved:
 - Read data, add data: 
 The program can read json files and add them

 - Show the usual graphs of each muscle or muscle group or exercise: 
 The program can generate graphs with matplotlib based on an exercise ar a muscle groups' sets, reps, highest weight or volume.

 - Include A LOT of exercises, from which you could always choose alternatives if you lack equipment or don't like the feel of an exercise: 
 A lot of exercises documented (Although will still be expanded), and you can filter through them based on what equipment or grip you want. Or if you want it do both sides (Like both biceps) at the same time or one at a time
 


